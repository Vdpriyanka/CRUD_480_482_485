<?php 
    
    $host = "http://crud.cywknhoi2srt.us-east-1.rds.amazonaws.com";
    $user = "admin";
    $pass = "Varshitha";
    $db_name = "crud";  
    $conn = new mysqli($host, $user, $pass, $db_name);
    if($conn->connect_error){
        die("Connect error".$conn->connect_error);
    }
 
    
    ?>